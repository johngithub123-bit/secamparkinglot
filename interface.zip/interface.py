import webview

webview.create_window('', url = 'display.html', fullscreen = True)

#webview.load_url('display.html')